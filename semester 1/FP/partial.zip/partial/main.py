from Repo.repo_carte import RepoCarte
from Service.service_carte import ServiceCarte
from ui.console import Console
from test import Test

repo = RepoCarte('Data/carte.txt')
service = ServiceCarte(repo)

console = Console(service)
console.run()

