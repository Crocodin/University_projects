from Domain.carte import Carte

class RepoCarte:

    def __init__(self, filename):
        self.__lista: list[Carte] = []
        self.__filename = filename

    def adauga_carte(self, carte: Carte):
        """
        adauga o carte la lista curenta
        :param carte: cartea care este adaugata
        :return: None
        """
        self.__lista.append(carte)

    def load(self):
        """
        citeste din fisier datele
        :return: None
        """
        with open(self.__filename, 'r') as file:
            for line in file:
                line.strip()
                nr, nume, autor, pret = line.split(',')
                carte = Carte(nr, nume, autor, int(pret))
                self.adauga_carte(carte)

    def get_all(self) -> list[Carte]:
        """
        returneaza toate cartile din lista curenta
        :return: o lista de carti
        """
        return self.__lista