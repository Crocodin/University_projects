import unittest

from Repo.repo_carte import RepoCarte
from Service.service_carte import ServiceCarte
from Domain.carte import Carte
from Errors.errors import *

class Test(unittest.TestCase):

    def setUp(self):
        self.repo = RepoCarte('Data/carte.txt')
        self.service = ServiceCarte(self.repo)

    def test_string_contains_string(self):
        self.assertTrue(self.service.string_contains_string("Marin Preda", "Marin"))
        self.assertTrue(self.service.string_contains_string("carte", "car"))
        self.assertTrue(self.service.string_contains_string("carte", "te"))
        self.assertTrue(self.service.string_contains_string("carte", "art"))
        self.assertFalse(self.service.string_contains_string("carte", "cartemea"))
        self.assertFalse(self.service.string_contains_string("carte", "ctr"))

    def test_autor_cu_string(self):
        lista = self.service.autor_cu_string("Marin")
        self.assertEqual(len(lista), 3)
        self.assertEqual(lista[0].get_autor(), "Marin Preda")
        self.assertRaises(CarteFoundError, self.service.autor_cu_string, "sdghfet")

    def test_get_book_with_name(self):
        self.assertEqual(self.service.get_book_with_name("Morometii").get_nume(), "Morometii")
        self.assertRaises(CarteFoundError, self.service.get_book_with_name, "fegyht")

    def test_adaugare_carte(self):
        carte = Carte('02','Crocodin','Codrin Parmac', 1000)
        self.repo.adauga_carte(carte)
        self.assertEqual(carte, self.service.get_book_with_name('Crocodin'))

    def test_get_all(self):
        self.assertEqual(len(self.repo.get_all()), 10)

    def test_load(self):
        aux_test_repo = RepoCarte('Data/carte.txt')
        self.assertEqual(aux_test_repo.get_all(), [])
        aux_test_repo.load()
        self.assertEqual(len(aux_test_repo.get_all()), 10)

    def test_carte_atribute(self):
        carte = Carte('02', 'Crocodin', 'Codrin Parmac', 1000)
        self.assertEqual(carte.get_nr(), '02')
        self.assertEqual(carte.get_nume(), 'Crocodin')
        self.assertEqual(carte.get_autor(), 'Codrin Parmac')
        self.assertEqual(carte.get_pret(), 1000)