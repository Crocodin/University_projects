from Service.service_carte import ServiceCarte
from Domain.carte import Carte
from Errors.errors import *

class Console:

    def __init__(self, service: ServiceCarte):
        self.__service = service

    def run(self):
        """
        ruleaza aplicatea
        :return: None
        """
        while True:
            # meniu principal ---------
            print("----------// Biblioteca //----------\n\n   1. Afis carti\n   2. Inchiriere carte\n   E. exit\n")
            option = input(">>> ").strip().upper()
            match option:
                case "1":
                    string = input("String: ").strip()
                    try:
                        lista_carti: list[Carte] = self.__service.autor_cu_string(string)
                        for carte in lista_carti:
                            print(f"{carte.get_nume()} - {carte.get_autor()}")
                    except CarteFoundError as e:
                        print(e)
                case "2":
                    nume = input("Nume carte: ").strip()
                    try:
                        nr_zile = int(input("Cate zile: ").strip())
                        if nr_zile <= 0:
                            raise ValueError
                        try:
                            carte = self.__service.get_book_with_name(nume)
                            print(f"----------// inchiriere //----------\n   {carte.get_nume()} - {carte.get_autor()}\n   Pret total: {carte.get_pret() * nr_zile}")
                        except CarteFoundError:
                            print("Cartea nu a fost gasita")
                    except ValueError:
                        print("Zile invalida, trebuie un numar pozitiv si difdrit de zero!")
                case "E" | "EXIT":
                    break
                case _:
                    print("Invalid option, incearca din nou!")