
class CarteFoundError(Exception):
    pass