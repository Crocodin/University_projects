from Domain.carte import Carte
from Repo.repo_carte import RepoCarte
from Errors.errors import *

class ServiceCarte:

    def __init__(self, repo: RepoCarte):
        self.__repo = repo
        self.__repo.load()

    @staticmethod
    def string_contains_string(string_1: str, string_2: str) -> bool:
        """
        verifica daca string_2 apare in string_1, nu conteaza daca sunt uppercase
        :param string_1: stringul in care cautam
        :param string_2: stringul cautat
        :return: true daca string_1 contine string_2, altfel false
        """
        return string_1.lower().find(string_2.lower()) != -1

    def autor_cu_string(self, string: str) -> list[Carte]:
        """
        verifica daca numele autorului contine stringul dat de utilizator
        :param string: stringul care se cauta
        :return: lista cu cartile a carot autor incepe cu stringul dat
        :raise: CarteFoundError, daca nu exist carte care indeplineste cerinta
        """
        lista_carti: list[Carte] = []
        for carte in self.__repo.get_all():
            if self.string_contains_string(carte.get_autor(), string):
                lista_carti.append(carte)
        if len(lista_carti) == 0:
            raise CarteFoundError(f"Nu am gasit nicio carte al carui autor incepe cu stringul {string}")
        return lista_carti

    def get_book_with_name(self, nume: str) -> Carte:
        """
        cauta cartea care are exact acest nume
        :param nume: numele cartii
        :return: carte cu acest nume
        :raise: CarteFoundError, daca nu exist cartea
        """
        for carte in self.__repo.get_all():
            if carte.get_nume() == nume:
                return carte
        raise CarteFoundError


