
class Carte:

    def __init__(self, nr: str, nume: str, autor: str, pret: int):
        self.__nr = nr
        self.__nume = nume
        self.__autor = autor
        self.__pret = pret

    def get_nr(self) -> str:
        """
        returneaza numarul de cartii de acest fel
        :return: string
        """
        return self.__nr

    def get_nume(self) -> str:
        """
        returneaza numele cartii
        :return: string
        """
        return self.__nume

    def get_autor(self) -> str:
        """
        returneaza autorul cartii
        :return: string
        """
        return self.__autor

    def get_pret(self) -> int:
        """
        returneaza pretul cartii pe zi
        :return: int, numar intreg pozitiv
        """
        return self.__pret